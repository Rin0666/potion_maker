package com.mobdeve.s18.terrado.rinzai.potion_maker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PotionCreated extends AppCompatActivity {
    Potion potion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.potion_created);

        Intent intent = getIntent();
        potion = (Potion)intent.getSerializableExtra("potion");
        buttonConfig();
        init();
    }
    private void init(){
        TextView potionName = (TextView) findViewById(R.id.potion_created_name);
        TextView potionIng1 = (TextView) findViewById(R.id.potion_created_ing1);
        TextView potionIng2 = (TextView) findViewById(R.id.potion_created_ing2);
        TextView potionIng3 = (TextView) findViewById(R.id.potion_created_ing3);
        ImageView bottle = (ImageView) findViewById(R.id.potion_created_bottle);

        potionName.setText(potion.getName());
        potionIng1.setText(potion.getIng1());
        potionIng2.setText(potion.getIng2());
        potionIng3.setText(potion.getIng3());
        if(potion.getIng3().equals("none") && potion.getIng2().equals("none")){
            bottle.setImageResource(R.drawable.abottle);
        } else if (potion.getIng3().equals("none") ){
            bottle.setImageResource(R.drawable.bbottle);
        } else{
            bottle.setImageResource(R.drawable.cbottle);
        }

    }
    private void buttonConfig(){
        Button buttonReturn = (Button) findViewById(R.id.button_created_return);
        buttonReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
