package com.mobdeve.s18.terrado.rinzai.potion_maker;

import java.io.Serializable;

public class Potion implements Serializable {
    private String name ="empty bottle";
    private String ing1 = "none";
    private String ing2 = "none";
    private String ing3 = "none";

    public Potion(String name, String ing1, String ing2, String ing3){
        this.name=name;
        this.ing1=ing1;
        this.ing2=ing2;
        this.ing3=ing3;
    }

    public Potion(){
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIng1() {
        return ing1;
    }

    public void setIng1(String ing1) {
        this.ing1 = ing1;
    }

    public String getIng2() {
        return ing2;
    }

    public void setIng2(String ing2) {
        this.ing2 = ing2;
    }

    public String getIng3() {
        return ing3;
    }

    public void setIng3(String ing3) {
        this.ing3 = ing3;
    }
    public void generateName(){
        this.name ="Unknown Potion";
        if(ing1.equals("ginseng") && ing2.equals("ginseng") && ing3.equals("ginseng") ||
                ing1.equals("ginseng") && ing2.equals("ginseng") && ing3.equals("none") ||
                ing1.equals("ginseng") && ing2.equals("none") && ing3.equals("none") ){
            this.name = "Eternal Youth Potion";
        }
        if(ing1.equals("cinnamon") && ing2.equals("cinnamon") && ing3.equals("cinnamon") ||
                ing1.equals("cinnamon") && ing2.equals("cinnamon") && ing3.equals("none") ||
                ing1.equals("cinnamon") && ing2.equals("none") && ing3.equals("none") ){
            this.name = "Internal Cleansing Potion";
        }
        if(ing1.equals("turmeric") && ing2.equals("turmeric") && ing3.equals("turmeric") ||
                ing1.equals("turmeric") && ing2.equals("turmeric") && ing3.equals("none") ||
                ing1.equals("turmeric") && ing2.equals("none") && ing3.equals("none") ){
            this.name = "Physical Cleansing Potion";
        }
        if(ing1.equals("sliced ginseng")){
            this.name =  "Insomnia Potion";
        }
        if(ing1.equals("sliced turmeric")){
            this.name =  "Rage Potion";
        }
        if(ing1.equals("sliced cinnamon")){
            this.name =  "Anxiety Potion";
        }
        if(ing1.equals("crushed ginseng")){
            this.name =  "Sleep Potion";
        }
        if(ing1.equals("crushed turmeric")){
            this.name =  "Tranquility Potion";
        }
        if(ing1.equals("crushed cinnamon")){
            this.name =  "Serenity Potion";
        }
        if(ing1.equals("mashed ginseng")){
            this.name =  "Insanity Potion";
        }
        if(ing1.equals("mashed turmeric")){
            this.name =  "Enlargening Potion";
        }
        if(ing1.equals("mashed cinnamon")){
            this.name =  "Shrinking Potion";
        }
        if(ing1.equals("mashed cinnamon") && ing2.equals("mashed turmeric") && ing3.equals("mashed ginseng")){
            this.name =  "Samsara Potion";
        }
        if(ing1.equals("crushed cinnamon") && ing2.equals("turmeric") && ing3.equals("sliced ginseng")){
            this.name =  "Cloning Potion";
        }
        if(ing1.equals("ginseng") && ing2.equals("cinnamon") && ing3.equals("turmeric")){
            this.name =  "Chi Expansion Potion";
        }
        if(ing1.equals("sliced ginseng") && ing2.equals("sliced cinnamon") && ing3.equals("sliced turmeric")){
            this.name =  "Chi Reduction Potion";
        }

    }
}
